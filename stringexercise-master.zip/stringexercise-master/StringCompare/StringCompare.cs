namespace StringCompare
{
    public static class StringCompare
    {
        public static bool AreEqual(string a, string b)
        {           
           

            if (RemoveSpace(a).ToLower().Equals(RemoveSpace(b).ToLower()))
                return true;
            else
                return false;
        }

        private static string RemoveSpace(string temp)
        {
            var temporary = "";
            for (int i = 0; i < temp.Length; i++)
            {
                if (temp[i].ToString() != " ")
                {
                    temporary = temporary + temp[i].ToString();
                }
            }
            return temporary;
        }

    }
}